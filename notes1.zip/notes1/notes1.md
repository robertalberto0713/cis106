# Notes 1

## What is Markdown?
Answer to the question goes here. I am just putting place holder text.
Tempor officia laboris incididunt ad aute mollit ex excepteur. Veniam ipsum consectetur magna sint nostrud. Ut anim aliquip minim nulla tempor. Adipisicing elit proident eu adipisicing Lorem voluptate anim culpa aliquip. Laborum consequat non amet tempor anim non quis dolor.


## What is Git?
Answer to the question goes here. I am just putting place holder text.
Tempor officia laboris incididunt ad aute mollit ex excepteur. Veniam ipsum consectetur magna sint nostrud. Ut anim aliquip minim nulla tempor. Adipisicing elit proident eu adipisicing Lorem voluptate anim culpa aliquip. Laborum consequat non amet tempor anim non quis dolor.



## What is GitHub?
Answer to the question goes here. I am just putting place holder text.
Tempor officia laboris incididunt ad aute mollit ex excepteur. Veniam ipsum consectetur magna sint nostrud. Ut anim aliquip minim nulla tempor. Adipisicing elit proident eu adipisicing Lorem voluptate anim culpa aliquip. Laborum consequat non amet tempor anim non quis dolor.


## What is Slack?
Answer to the question goes here. I am just putting place holder text.
Tempor officia laboris incididunt ad aute mollit ex excepteur. Veniam ipsum consectetur magna sint nostrud. Ut anim aliquip minim nulla tempor. Adipisicing elit proident eu adipisicing Lorem voluptate anim culpa aliquip. Laborum consequat non amet tempor anim non quis dolor.
